#include <stdio.h>
#include <inttypes.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <string.h>
#include "setjmp828.h"
#include "testjmp.h"

typedef struct test test_t;
struct test {
	char pad[1024];
	regs_t r;
};

void
usage(void)
{
	fprintf(stderr, "usage: testjmp [seed]\n");
	exit(1);
}

void
printstackenv(stackenv_t *env)
{
	printf("ebp=%x ebx=%x esi=%x edi=%x esp=%x ret=%x",
		env->ebp, env->ebx, env->esi, env->edi, env->esp, env->ret);
}

void
printregs(regs_t *r)
{
	printf("edi=%x esi=%x ebp=%x esp=%x ebx=%x edx=%x ecx=%x eax=%x ret=%x",
		r->edi, r->esi, r->ebp, r->esp, r->ebx, r->edx,
		r->ecx, r->eax, r->ret);
}

void
randregs(regs_t *r)
{
	int i, n;
	uint32_t *p;

	n = sizeof(*r)/sizeof(uint32_t);
	p = (uint32_t*)r;
	for(i=0; i<n; i++)
		p[i] = rand()^(rand()<<16);
}

void
randenv(stackenv_t *e)
{
	int i, n;
	uint32_t *p;

	n = sizeof(*e)/sizeof(uint32_t);
	p = (uint32_t*)e;
	for(i=0; i<n; i++)
		p[i] = rand()^(rand()<<16);
}

enum
{
	SETJMP_EBP,
	SETJMP_EBX,
	SETJMP_ESI,
	SETJMP_EDI,
	SETJMP_ESP,
	SETJMP_RET,
	SETJMP_EAX,
	SETJMP_TRASHEBP,
	SETJMP_TRASHEBX,
	SETJMP_TRASHESI,
	SETJMP_TRASHEDI,
	SETJMP_TRASHESP,
	SETJMP_COUNT,
};
char *setjmperr[SETJMP_COUNT] = {
	"save EBP in env",
	"save EBX in env",
	"save ESI in env",
	"save EDI in env",
	"save ESP in env",
	"save return address in env",
	"return correct EAX",
	"preserve EBP",
	"preserve EBX",
	"preserve ESI",
	"preserve EDI",
	"preserve ESP",
};

enum
{
	LONGJMP_EBP,
	LONGJMP_EBX,
	LONGJMP_ESI,
	LONGJMP_EDI,
	LONGJMP_ESP,
	LONGJMP_RET,
	LONGJMP_EAX,
	LONGJMP_ENV,
	LONGJMP_COUNT,
};
char *longjmperr[LONGJMP_COUNT] = {
	"restore EBP",
	"restore EBX",
	"restore ESI",
	"restore EDI",
	"restore ESP",
	"restore return address",
	"set EAX properly",
	"preserve struct stackenv",
};

uint32_t
testsetjmp1(void)
{
	test_t in, ou;
	stackenv_t env;
	uint32_t bad;

	memset(&in, 0, sizeof in);
	randregs(&in.r);
	memset(&ou, 0, sizeof ou);
	randenv(&env);

	testsetjmp(&in.r, &ou.r, &env);

	bad = 0;
	if(env.ebp != in.r.ebp)
		bad |= 1<<SETJMP_EBP;
	if(env.ebx != in.r.ebx)
		bad |= 1<<SETJMP_EBX;
	if(env.esi != in.r.esi)
		bad |= 1<<SETJMP_ESI;
	if(env.edi != in.r.edi)
		bad |= 1<<SETJMP_EDI;
	if(env.esp != in.r.esp)
		bad |= 1<<SETJMP_ESP;
	if(env.ret != in.r.ret)
		bad |= 1<<SETJMP_RET;
	if(ou.r.eax != 0)
		bad |= 1<<SETJMP_EAX;
	if(ou.r.ebp != in.r.ebp)
		bad |= 1<<SETJMP_TRASHEBP;
	if(ou.r.ebx != in.r.ebx)
		bad |= 1<<SETJMP_TRASHEBX;
	if(ou.r.esi != in.r.esi)
		bad |= 1<<SETJMP_TRASHESI;
	if(ou.r.edi != in.r.edi)
		bad |= 1<<SETJMP_TRASHEDI;
	if(ou.r.esp != in.r.esp)
		bad |= 1<<SETJMP_TRASHESP;
	return bad;
}

uint32_t
testlongjmp1(void)
{
	test_t in, ou;
	stackenv_t env, env0;
	uint32_t ret;
	uint32_t bad;

	ret = rand();
	memset(&in, 0, sizeof in);
	randregs(&in.r);
	memset(&ou, 0, sizeof ou);
	randenv(&env);
	memmove(&env0, &env, sizeof env);

	testlongjmp(&in.r, &ou.r, &env, ret);

	bad = 0;
	if(ou.r.ebp != env0.ebp)
		bad |= 1<<LONGJMP_EBP;
	if(ou.r.ebx != env0.ebx)
		bad |= 1<<LONGJMP_EBX;
	if(ou.r.esi != env0.esi)
		bad |= 1<<LONGJMP_ESI;
	if(ou.r.edi != env0.edi)
		bad |= 1<<LONGJMP_EDI;
	if(ou.r.eax != ret)
		bad |= 1<<LONGJMP_EAX;
	if(ou.r.esp != in.r.esp+4) /* testlongjmp sets in.r.esp for us */
		bad |= 1<<LONGJMP_ESP;
	if(ou.r.ret)
		bad |= 1<<LONGJMP_RET;
	if(env.ebp != env0.ebp
	|| env.ebx != env0.ebx
	|| env.esi != env0.esi
	|| env.edi != env0.edi
	|| env.esp != in.r.esp
	|| env.ret != in.r.ret)
		bad |= 1<<LONGJMP_ENV;
	return bad;
}
	
int
main(int argc, char **argv)
{
	int score, seed, i, worked;
	uint32_t bad;
	stackenv_t env;

	if(argc > 2)
		usage();
	if(argc == 1){
		seed = (getpid()<<16)^time(0);
		printf("testjmp %d\n", seed);
	}else{
		seed = atoi(argv[1]);
	}

	srand(seed);

	bad = 0;
	score = 0;
	for(i=0; i<32; i++)
		bad |= testsetjmp1();
	for(i=0; i<SETJMP_COUNT; i++){
		if(bad & (1<<i))
			printf("-1 setjmp828 does not %s\n", setjmperr[i]);
		else{
			printf("+1 setjmp828 does %s\n", setjmperr[i]);
			score++;
		}
	} 

	bad = 0;
	for(i=0; i<32; i++)
		bad |= testlongjmp1();
	for(i=0; i<LONGJMP_COUNT; i++){
		if(bad & (1<<i))
			printf("-1 longjmp828 does not %s\n", longjmperr[i]);
		else{
			printf("+1 longjmp828 does %s\n", longjmperr[i]);
			score++;
		}
	} 

	fflush(stdout);

	worked = 0;
	switch(setjmp828(&env)){
	case 0:
		longjmp828(&env, 12345);
		break;
	case 12345:
		worked = 1;
		break;
	}

	if(!worked)
		printf("-10 setjmp828 and longjmp828 don't work in simple test\n");
	else{
		printf("+10 setjmp828 and longjmp828 work in simple test\n");
		score += 10;
	}
	
	printf("%d/%d\n", score, SETJMP_COUNT+LONGJMP_COUNT+10);
	return 0;
}
