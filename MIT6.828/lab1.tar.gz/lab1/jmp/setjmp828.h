typedef struct stackenv stackenv_t;

struct stackenv
{
	uint32_t ebp;
	uint32_t ebx;
	uint32_t esi;
	uint32_t edi;
	uint32_t esp;
	uint32_t ret;
};

int setjmp828(stackenv_t *env);
void longjmp828(stackenv_t *env, int rv);

