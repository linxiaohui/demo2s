typedef struct regs regs_t;
struct regs
{
	uint32_t edi;
	uint32_t esi;
	uint32_t ebp;
	uint32_t esp;
	uint32_t ebx;
	uint32_t edx;
	uint32_t ecx;
	uint32_t eax;
	uint32_t ret;
};

void testsetjmp(regs_t*, regs_t*, stackenv_t*);
void testlongjmp(regs_t*, regs_t*, stackenv_t*, int);

