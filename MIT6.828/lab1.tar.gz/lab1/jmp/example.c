#include <stdio.h>
#include <inttypes.h>
#include "setjmp828.h"

void f(void);
void g(void);
void h(void);

stackenv_t env;

int
main(void)
{
	printf("entering main\n");
	switch(setjmp828(&env)){
	case 0:
		printf("setjmp828 returned 0\n");
		f();
		break;
	case 1:
		printf("setjmp828 returned 1\n");
		g();
		break;
	case 2:
		printf("setjmp828 returned 2\n");
		break;
	}
	printf("exiting main\n");
	return 0;
}

void
f(void)
{
	printf("entering f\n");
	longjmp828(&env, 1);
	printf("exiting f\n");
}

void
g(void)
{
	printf("entering g\n");
	h();
	printf("exiting g\n");
}

void
h(void)
{
	printf("entering h\n");
	longjmp828(&env, 2);
	printf("exiting h\n");
}

